				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

import java.util.ArrayList;

/**
 * The Class Movable.
 * 
 * Adapted from Sample 2a
 * 
 * Encompasses all movable objects
 */
public class Movable extends Sprite {

	/**
	 * Instantiates a new movable.
	 *
	 * @param isBlocked the is blocked
	 * @param image_src the image source code
	 * @param x the x location
	 * @param y the y location
	 */
	Movable(boolean isBlocked, String image_src, float x, float y) {
		super(isBlocked, image_src, x, y);
	}
	
	/**
	 * Move by 1 tile in specified direction if move is possible.
	 *
	 * @param dir the dir
	 * @return true, if successful
	 */
	public boolean moveToDest(int dir) {
		float speed = App.TILE_SIZE;
		
		// Translate the direction to an x and y displacement
		float delta_x = 0,
			  delta_y = 0;
		
		switch (dir) {
			case DIR_LEFT:
				delta_x = -speed;
				break;
			case DIR_RIGHT:
				delta_x = speed;
				break;
			case DIR_UP:
				delta_y = -speed;
				break;
			case DIR_DOWN:
				delta_y = speed;
				break;
		}
		
		// Make sure the position isn't occupied!
		if (!Loader.isBlocked(super.getX() + delta_x, super.getY() + delta_y)) {
			super.setX(super.getX() + delta_x);
			super.setY(super.getY() + delta_y);
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Undo.
	 *
	 * @param moves the moves ArrayList
	 * @return an int
	 */
	// Undoing moves
	public int undo(ArrayList<Move> moves) {
		if(moves.size() > 1) {
			int index = moves.size()-1;
			Move latestMove = moves.get(index);
			
			//undo the corresponding Movable only when player MoveCount is the same
			if(latestMove.getMoveCount()==Player.getMoveCount()) {
				moves.remove(index);
				Move prevMove = moves.get(moves.size()-1);
				super.setX(prevMove.getX());
				super.setY(prevMove.getY());
				return prevMove.getMoveCount();
			}
		}
		return 0;
	}
	
	/**
	 * Checks if player is near block.
	 *
	 * @param player the player
	 * @param x the x loc
	 * @param y the y loc
	 * @return true, if player is near block
	 */
	public boolean isPlayerNearBlock(Player player, float x, float y) {
		float speed = App.TILE_SIZE;
		// Translate the direction to an x and y displacement
		float delta_x = 0,
			  delta_y = 0;
		switch (Player.getDir()) {
			case DIR_LEFT:
				delta_x = -speed;
				break;
			case DIR_RIGHT:
				delta_x = speed;
				break;
			case DIR_UP:
				delta_y = -speed;
				break;
			case DIR_DOWN:
				delta_y = speed;
				break;
		}
		return (player.getX() + delta_x == x && player.getY() + delta_y == y);
	}
}
