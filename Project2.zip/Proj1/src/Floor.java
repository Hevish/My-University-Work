				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

/**
 * The Class Floor.
 */
public class Floor extends Tile {
	
	/**
	 * Instantiates a new floor.
	 *
	 * @param x the x location
	 * @param y the y location
	 */
	public Floor(float x, float y){
		super(false, "res/floor.png", x, y);
	}
}
