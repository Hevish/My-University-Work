				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

import java.util.ArrayList;

import org.newdawn.slick.Input;

/**
 * The Class Block.
 */
public class Block extends Movable {
	
	/** The block moves. */
	private ArrayList<Move> blockMoves = new ArrayList<Move>();
	
	/**
	 * Instantiates a new block.
	 *
	 * @param isBlocked the blocked state
	 * @param image_src the image source code
	 * @param x the x location
	 * @param y the y location
	 */
	Block(boolean blocked, String image_src, float x, float y) {
		super(blocked, image_src, x, y);
		blockMoves.add(new Move( Player.getMoveCount(), x, y));
	}
	
	@Override
	public void update(Input input, int delta) {
		
		Player player = World.getPlayer();
			// if player is pushing block, push block accordingly
			if((isPlayerNearBlock(player, super.getX(), super.getY())) && !Player.onMove()) {
				int dir = Player.getDir();
				if (moveToDest(dir)) {
					blockMoves.add(new Move( Player.getMoveCount(), super.getX(), super.getY()));
				}
				player.moveToDest(dir);

			}
			// undo blocks if player is undoing
			if(Player.undo()) {
				undo(blockMoves);
			}		
	}

	/**
	 * Checks state of all Targets and return if they are activated, so we can change level
	 * @return true, if successful
	 */
	public static boolean areTargetsActivated() {
		
		// Generating ArrayList of blocks
		ArrayList<Sprite> targets = World.getSpritesOfType("target");
		ArrayList<Sprite> blocks = World.getSpritesOfType("stone");
		ArrayList<Sprite> ice = World.getSpritesOfType("ice");
		blocks.addAll(ice);
		
		boolean canSwitchLevel=false;
		// null check
		if(!targets.isEmpty()) {
			for(Sprite t:targets) {
				for(Sprite b : blocks) {
					// if block is on target, check next target
					if(t.getX()==b.getX() && t.getY()==b.getY()) {
						canSwitchLevel = true;
						break;
					}
				}
				if (canSwitchLevel) {
					canSwitchLevel = false;
				} else {
					return false;
				}
			}
			return true;
		}
		else {
			//no target, this is the last level
			return false;
		}
	}
}


