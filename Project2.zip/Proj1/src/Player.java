			/* Name: Hevish Cowlessur
				 * 771425 
				 * (PLAYER CLASS)
				 *  */


import java.util.ArrayList;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

/**
 * The Class Player.
 * 
 * Adapted from Sample solution
 * 
 * This subclass represents the player which inherits the attributes and methods of the parent class Sprite
 */
public class Player extends Movable {
	
	/** The Constant PLAYER_SRC. */
	public static final String PLAYER_SRC = "res/player_left.png";

	/** The move count. */
	private static int moveCount;
	
	/** The is moving. */
	private static boolean isMoving =false;
	
	/** The un doing. */
	private static boolean unDoing = false;
	
	/** The is key pressed. */
	private static boolean isKeyPressed = false;
	
	/** The player moves. */
	private ArrayList<Move> playerMoves= new ArrayList<Move>(); 
	
	/** The dir. */
	private static int dir;
	
	/**
	 * Instantiates a new player.
	 *
	 * @param x the x
	 * @param y the y
	 * @throws SlickException the slick exception
	 */
	Player(float x, float y) throws SlickException {
		super(false,PLAYER_SRC, x, y);
		playerMoves.add(new Move(
				getMoveCount(), x, y));
	}
	
	/* 
	 * Movement of player using arrow keys
	 */
	@Override
	public void update(Input input, int delta) {
		
		/* Check if new tile is blocked. update position iff new tile is not blocked */
		/* Call isBlocked method from Loader class to check the blocked state of tiles */
		dir = DIR_NONE;
		//decrease y coordinate
		if (input.isKeyPressed(Input.KEY_UP)) {  
			isKeyPressed = true;
			isMoving = false;
			dir = DIR_UP;
			moveToDest(dir);
			
		}
		//increase y coordinate
		else if (input.isKeyPressed(Input.KEY_DOWN)) {   
			isKeyPressed = true;
			dir = DIR_DOWN;
			moveToDest(dir);
			
		}
		//decrease x coordinate
		else if (input.isKeyPressed(Input.KEY_LEFT)) {	
			isKeyPressed = true;
			dir = DIR_LEFT;
			moveToDest(dir);
			
		}
		//increase x coordinate
		else if (input.isKeyPressed(Input.KEY_RIGHT)) {	
			isKeyPressed = true;
			dir = DIR_RIGHT;
			moveToDest(dir);
			
		}
		// undo player moves
		else if (input.isKeyPressed(Input.KEY_Z) && getMoveCount() >= 0 ) {
			setMoveCount(undo(playerMoves));
			unDoing = true;
			
	    }
		else{
			isMoving = false;
			unDoing = false;
			isKeyPressed = false;
		}

	}
	
	// Move to next tile if it is not blocked
	public boolean moveToDest(int dir) {
		float speed = App.TILE_SIZE;
		// Translate the direction to an x and y displacement
		float delta_x = 0,
			  delta_y = 0;
		
		switch (dir) {
			case DIR_LEFT:
				delta_x = -speed;
				break;
			case DIR_RIGHT:
				delta_x = speed;
				break;
			case DIR_UP:
				delta_y = -speed;
				break;
			case DIR_DOWN:
				delta_y = speed;
				break;
		}
		// Make sure the position isn't occupied!
		if (!Loader.isBlocked(super.getX() + delta_x, super.getY() + delta_y)) {
			
			super.setX(super.getX()+delta_x);
			super.setY(super.getY()+delta_y);
			
			isMoving = true;
			setMoveCount(getMoveCount() + 1);
			playerMoves.add(new Move( getMoveCount(),super.getX(), super.getY()));
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * On move.
	 *
	 * @return true, if successful
	 */
	// returns if player is moving
	public static boolean onMove() {
		return isMoving;
	}
	
	/**
	 * Undo.
	 *
	 * @return true, if successful
	 */
	// return if player is undoing 
	public static boolean undo() {
		return unDoing;
	}
	
	/**
	 * Key pressed.
	 *
	 * @return true, if successful
	 */
	//returns if arrow key is pressed
	public static boolean keyPressed() {
		return isKeyPressed;
	}
	
	/*@@@ GETTERS AND SETTERS @@@*/
	/**
	 * Gets the move count.
	 *
	 * @return the move count
	 */
	public static int getMoveCount() {
		return moveCount;
	}
	
	/**
	 * Sets the move count.
	 *
	 * @param move the new move count
	 */
	public static  void setMoveCount(int move) {
		moveCount = move;
	}	
	
	/**
	 * Gets the dir.
	 *
	 * @return the dir
	 */
	public static int getDir() {
		return dir;
	}
	
	/**
	 * Sets the dir.
	 *
	 * @param dir the new dir
	 */
	public void setDir(int dir) {
		Player.dir = dir;
	}
}