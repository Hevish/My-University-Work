				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

/**
 * The Class TNT.
 */
public class TNT  extends Block {	
	
	/** Distance infinity */
	private final int INFINITY = 10000;
	
	/** The destroyed state of cracked wall */
	private static boolean destroyed = false;

	/**
	 * Instantiates a new tnt.
	 *
	 * @param x the x
	 * @param y the y
	 */
	TNT(float x, float y) {
		super(true, "res/tnt.png", x, y);
	}
	
	@Override
	public void update(Input input, int delta) {
		
		Player player = World.getPlayer();
		Sprite cracked = World.getSpritesOfType("cracked_wall").get(0);

			if(Player.getDir()==DIR_DOWN && !Player.onMove()) {
				if(super.getX() == cracked.getX() && super.getY() == cracked.getY()-32) {
					
					//Send out of screen	
					super.setX(INFINITY);
					super.setY(INFINITY);
					
					try {
						super.setImage(new Image("res/floor.png"));
					} catch (SlickException e) {
						e.printStackTrace();
					}
					destroyed = true;
					super.setBlocked(false);
					player.moveToDest(DIR_DOWN);
			}
		}
			super.update(input, delta);
	}

	/**
	 * Checks if cracked wall is destroyed.
	 *
	 * @return true, if cracked wall is destroyed
	 */
	public static boolean isDestroyed() {
		return destroyed;
	}

	/**
	 * Sets the destroyed state of cracked wall
	 *
	 * @param isDestroyed the new destroyed stated
	 */
	public static void setDestroyed(boolean isDestroyed) {
		TNT.destroyed = isDestroyed;
	}
}
