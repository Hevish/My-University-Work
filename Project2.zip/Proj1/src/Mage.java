				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

import org.newdawn.slick.Input;

/**
 * The Class Mage.
 */
public class Mage extends Monster {

	/**
	 * Instantiates a new mage.
	 *
	 * @param x the x location
	 * @param y the y location
	 */
	Mage(float x, float y) {
		super(false,"res/mage.png", x, y);
	}
	
	@Override
	public void update(Input input, int delta) {
		Player player = World.getPlayer();
		
		// The Mage Algorithm
		int signX=1;
		int signY=1;
		float distX = player.getX()- super.getX();
		float distY = player.getY()  - super.getY();
		
		if(distX < 0 ) {
			signX = -1;
		}else {
			signX=1;
		}
		if(distY < 0 ) {
			signY = -1;
		}else {
			signY=1;
		}
		
		// Movement in x direction
		if((Math.abs(distX) > Math.abs(distY)) && Player.onMove()) {
			
			if(!Loader.isBlocked(super.getX() + signX*App.TILE_SIZE, super.getY())){
				super.setX((super.getX() + signX*App.TILE_SIZE));
			}			
		}
		// Movement in x direction
		else if((Math.abs(distX) < Math.abs(distY)) && Player.onMove()) {
			if(!Loader.isBlocked(super.getX(), super.getY() + signY*App.TILE_SIZE)){
				super.setY((super.getY() + signY*App.TILE_SIZE));
			}
		}
		
		// Inherit Monster update method so mage is able to kill player
		super.update(input, delta);
	}
}
