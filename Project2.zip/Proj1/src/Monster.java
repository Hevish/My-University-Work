				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

import org.newdawn.slick.Input;

// TODO: Auto-generated Javadoc
/**
 * The Class Monster.
 */
public abstract class Monster extends Movable {
	
	/** State of player (dead or alive) */
	private static boolean isPlayerDead = false;
	
	/**
	 * Instantiates a new monster.
	 *
	 * @param blocked the blocked
	 * @param image_src the image source code
	 * @param y the y location
	 */
	Monster(boolean blocked, String image_src, float x, float y) {
		super(blocked, image_src, x, y);
		
	}
	
	@Override
	public void update(Input input, int delta) {
		
		Player player = World.getPlayer();
		isPlayerDead = false;
		
		// If monster and player location match, restart level 
		if(player.getX()==super.getX() && player.getY()==super.getY()) {
			isPlayerDead = true; 
			restartLevel();
			return;
		}
	}
	
	/**
	 * Restart level.
	 *
	 * @return true, if successful
	 */
	public static boolean restartLevel() {
		return isPlayerDead;	
	}
}
