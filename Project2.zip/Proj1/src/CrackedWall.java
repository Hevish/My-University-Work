				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

/**
 * The Class CrackedWall.
 */
public class CrackedWall extends Sprite {
	
	/** The Constant EXPLOSION_DURATION. */
	private final int EXPLOSION_DURATION = 400;
	
	/** Timer */
	private int timer = 0;
	
	/** The Constant INFINITY. */
	private final int INFINITY = 10000;

	/**
	 * Instantiates a new cracked wall.
	 *
	 * @param x the x location
	 * @param y the y location
	 */
	CrackedWall(float x, float y) {
		super(true, "res/cracked_wall.png", x, y);
	}

	@Override
	public void update(Input input, int delta) {
		
		// Display explosion at cracked wall location only if tnt is pushed into it
		if (TNT.isDestroyed()) {
			timer += delta;
			
			if (TNT.isDestroyed() && timer < EXPLOSION_DURATION) {
				
				try {
					super.setImage(new Image("res/explosion.png"));
	
				} catch (SlickException e) {
					e.printStackTrace();
				}
				
			}
			// Remove cracked wall by sending the sprite out of screen
			if (timer > EXPLOSION_DURATION) {
				super.setX(INFINITY);
				super.setY(INFINITY);
				super.setBlocked(false);
			}
		}
	}
}



