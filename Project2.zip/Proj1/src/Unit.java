				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

/**
 * The Class Unit.
 */
public abstract class Unit extends Movable{

	/**
	 * Instantiates a new unit.
	 *
	 * @param isBlocked the is blocked
	 * @param image_src the image source code
	 * @param x the x location
	 * @param y the y location
	 */
	Unit(boolean isBlocked, String image_src, float x, float y) {
		super(isBlocked, image_src, x, y);
	}
}
