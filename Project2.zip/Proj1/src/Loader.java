				/* Name: Hevish Cowlessur 
				 * 771425 
				 * (LOADER CLASS) */



import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import org.newdawn.slick.SlickException;

/**
 * The Class Loader.
 */

/*This class loads the sprites from the CSV file*/
public class Loader {
	
	/** The Constant SPLITTER. */
	/* Defining constants*/
	public static final String SPLITTER = ",";

	/** The Constant CRACKED_SRC. */
	public static final String CRACKED_SRC = "res/cracked_wall.png";
	
	/** The Constant DOOR_SRC. */
	public static final String DOOR_SRC = "res/door.png";
	
	/** The Constant ICE_SRC. */
	public static final String ICE_SRC = "res/ice.png";
	
	/** The Constant SWITCH_SRC. */
	public static final String SWITCH_SRC = "res/switch.png";
	
	/** The Constant MAGE_SRC. */
	public static final String MAGE_SRC = "res/mage.png";
	
	/** The Constant SKULL_SRC. */
	public static final String SKULL_SRC = "res/skull.png";
	
	/** The Constant ROGUE_SRC. */
	public static final String ROGUE_SRC = "res/rogue.png";
	
	/** The Constant PLAYER. */
	public static final String PLAYER = "player"; 
	
	/** The Constant FLOOR. */
	public static final String FLOOR = "floor";
	
	/** The Constant STONE. */
	public static final String STONE = "stone";
	
	/** The Constant TARGET. */
	public static final String TARGET = "target";
	
	/** The Constant WALL. */
	public static final String WALL = "wall";
	
	/** The Constant CRACKED. */
	public static final String CRACKED = "cracked";
	
	/** The Constant DOOR. */
	public static final String DOOR = "door";
	
	/** The Constant ICE. */
	public static final String ICE = "ice";
	
	/** The Constant SWITCH. */
	public static final String SWITCH = "switch";
	
	/** The Constant MAGE. */
	public static final String MAGE = "mage";
	
	/** The Constant SKULL. */
	public static final String SKULL = "skeleton";
	
	/** The Constant ROGUE. */
	public static final String ROGUE = "rogue";
	
	/** The Constant TNT. */
	public static final String TNT = "tnt";

	/** The Constant NUMOFDATAPERLINE. */
	public static final int NUMOFDATAPERLINE = 3;
	
	/** The sprite. */
	private static ArrayList<Sprite> sprite = new ArrayList<Sprite>();
	
	/** The target. */
	private static ArrayList<Sprite> target = new ArrayList<Sprite>();
	
	/** The block. */
	private static ArrayList<Sprite> block = new ArrayList<Sprite>();
	
	/**
	 * Loads the sprite from a given file.
	 *
	 * @param filename the filename
	 * @return the array list
	 * @throws SlickException the slick exception
	 */
	public static ArrayList<Sprite> loadSprites(String filename) throws SlickException {
		
		/*read CSV file*/
		try (BufferedReader br = new BufferedReader (new FileReader(filename))) {
			
			String lineArgs;
			/* Extract first line of CSV file. Contains info about game size */
			String[] firstLineArgs = br.readLine().split(SPLITTER);
			String[] tileData = new String[NUMOFDATAPERLINE];
			/* Extract game size*/
			int gameWidth = Integer.parseInt(firstLineArgs[0])*App.TILE_SIZE ;
			int gameLength = Integer.parseInt(firstLineArgs[1])*App.TILE_SIZE ;
			
			while ((lineArgs = br.readLine()) != null) {
				
				/* Store each of the remaining lines in a temporary tileData array of three strings */
				tileData = lineArgs.split(SPLITTER);
				
				/*Calculate position of tile so as the game screen is centered*/
				float xPos = (App.SCREEN_WIDTH-gameWidth)/2 + Integer.parseInt(tileData[1])*App.TILE_SIZE;
				float yPos = (App.SCREEN_HEIGHT-gameLength)/2 + Integer.parseInt(tileData[2])*App.TILE_SIZE;
				
				String tileType = tileData[0]; //get the tileType from first string of tileType array
				
				switch(tileType) {
				
				/*construct the sprite and increment the arrayList with sprites*/
					case PLAYER:
						sprite.add( new Player(xPos, yPos));
						break;
					case FLOOR:
						sprite.add( new Floor(xPos, yPos));
						break;
					case STONE:
						sprite.add( new Stone(xPos, yPos));
						block.add(new Stone(xPos, yPos));
						break;
					case TARGET:
						sprite.add( new Target(xPos, yPos));
						target.add(new Target(xPos, yPos));
						break;	
					case WALL:
						sprite.add( new Wall(xPos, yPos));
						break;
					case CRACKED:
						sprite.add( new CrackedWall(xPos, yPos));
						break;
					case DOOR:
						sprite.add( new Door(xPos, yPos));
						break;
					case ICE:
						sprite.add( new Ice(xPos, yPos));
						block.add(new Ice(xPos, yPos));
						break;
					case SWITCH:
						sprite.add( new Switch(xPos, yPos));
						break;
					case MAGE:
						sprite.add( new Mage(xPos, yPos));
						break;
					case SKULL:
						sprite.add( new Skeleton(xPos, yPos));
						break;
					case ROGUE:
						sprite.add( new Rogue(xPos, yPos));
						break;
					case TNT:
						sprite.add( new TNT(xPos, yPos));
						block.add(new TNT(xPos, yPos));
						break;
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return sprite;
	}
	
	/**
	 * Checks if is blocked.
	 *
	 * @param x the x location
	 * @param y the y location
	 * @return true, if is blocked
	 */
	/* This method is to check the tile with coordinates (x,y) is blocked or not */
	public static boolean isBlocked(float x, float y) {
		for(int i = 0 ; i < sprite.size() ;  i++) { 
			/* if (x,y) corresponds to that of a blocked tile, return true*/
			if((sprite.get(i).getX() == x) && (sprite.get(i).getY() == Math.round(y)) && (sprite.get(i).getIsBlocked(x, y))){
				return true;
			}
		}
		return false;
	}
	/* GETTERS AND SETTERS */
	
	/**
	 * Gets the sprite.
	 *
	 * @return the sprite
	 */
	public static ArrayList<Sprite> getSprite() {
		return sprite;
	}

	/**
	 * Sets the sprite.
	 *
	 * @param sprite the new sprite
	 */
	public static void setSprite(ArrayList<Sprite> sprite) {
		Loader.sprite = sprite;
	}

	/**
	 * Gets the target.
	 *
	 * @return the target
	 */
	public static ArrayList<Sprite> getTarget() {
		return target;
	}

	/**
	 * Sets the target.
	 *
	 * @param target the new target
	 */
	public static void setTarget(ArrayList<Sprite> target) {
		Loader.target = target;
	}

	/**
	 * Gets the block.
	 *
	 * @return the block
	 */
	public static ArrayList<Sprite> getBlock() {
		return block;
	}

	/**
	 * Sets the block.
	 *
	 * @param block the new block
	 */
	public static void setBlock(ArrayList<Sprite> block) {
		Loader.block = block;
	}
}