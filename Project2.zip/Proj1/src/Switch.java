				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

/**
 * The Class Switch.
 */
public class Switch extends Tile {

	/**
	 * Instantiates a new switch.
	 *
	 * @param x the x location
	 * @param y the y location
	 */
	Switch(float x, float y) {
		super(false, "res/switch.png", x, y);
	}
	
	@Override
	public void update(Input input, int delta) {

		//In level concerned there are only 1 of each stone and ice, so get(0) works just fine
		// Can be extended if there are more blocks
		Sprite stone = World.getSpritesOfType("stone").get(0);
		Sprite door = World.getSpritesOfType("door").get(0);
		Sprite ice = World.getSpritesOfType("ice").get(0);
		
		// if block is on switch replace door by a floor
		if((stone.getX()==super.getX() && stone.getY()==super.getY()) ||(ice.getX()==super.getX() && ice.getY()==super.getY())) {
			try {
				door.setImage(new Image("res/floor.png"));
				door.setBlocked(false);
			} catch (SlickException e) {
				e.printStackTrace();
			}
			
		}
		// if block is not switch replace door back
		else {
			try {
				door.setImage(new Image("res/door.png"));
				door.setBlocked(true);
			} catch (SlickException e) {
				e.printStackTrace();
			}
		}
	}
}
