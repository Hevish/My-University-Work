				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

/**
 * The Class Tile.
 */
public abstract class Tile extends Sprite {

	/**
	 * Instantiates a new tile.
	 *
	 * @param isBlocked the is blocked
	 * @param image_src the image source code
	 * @param x the x location
	 * @param y the y location
	 */
	Tile(boolean isBlocked, String image_src, float x, float y) {
		super(isBlocked, image_src, x, y);
	}

	

}
