				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

/**
 * The Class Effect.
 * 
 *  Making Effect an abstract class as there can be more effects in the game
 * 
 */
public abstract class Effect extends Sprite {

	/**
	 * Instantiates a new effect.
	 *
	 * @param blocked the blocked state
	 * @param image_src the image source code
	 * @param x the x location
	 * @param y the y location
	 */
	Effect(boolean blocked, String image_src, float x, float y) {
		super(blocked, image_src, x, y);
	}
}
