				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

import org.newdawn.slick.Input;

/**
 * The Class Rogue.
 */
public class Rogue extends Monster{
	
	/** Rogue's direction of motion */
	private boolean isMovingLeft = true;
	
	/**
	 * Instantiates a new rogue.
	 *
	 * @param x the x location
	 * @param y the y location
	 */
	public Rogue(float x, float y) {		
		super(false, "res/rogue.png", x, y);
	}
	
	
	@Override
	public void update(Input input, int delta) {
		
		Block block = null;
		
		float xLeft=super.getX() - App.TILE_SIZE;
		float xRight=super.getX() + App.TILE_SIZE;
		float y = super.getY();
		
		// Should move every time arrow key is pressed
		if(Player.keyPressed()) {
			
			// Cases where Rogue is not blocked
			if(!Loader.isBlocked(xLeft,y) && isMovingLeft){
				super.setX(xLeft);
			}
			else if(!Loader.isBlocked(xRight, y) && !isMovingLeft) {
				super.setX(xRight);		
			}
			// Cases where Rogue is blocked by a wall
			else if(Loader.isBlocked(xRight, y) && !World.isABlock(xRight, y)){
				isMovingLeft = true;
			}
			else if(Loader.isBlocked(xLeft, y) && !World.isABlock(xLeft, y)) {
				isMovingLeft = false;
			}
			// Cases where Rogue is blocked by a block and has to check if it can move, then move it
			else if(Loader.isBlocked(xRight, y) && World.isABlock(xRight, y)){
				
				block = World.getBlock(xRight, y);
				
				if(!Loader.isBlocked(block.getX()+App.TILE_SIZE, y)) {
					block.setX(xRight+App.TILE_SIZE);
					isMovingLeft = false;
					super.moveToDest(DIR_RIGHT);
				}
				else {
					isMovingLeft = true;
				}
				
				
			}	
			else if(Loader.isBlocked(xLeft, y) && World.isABlock(xLeft, y)){
				block = World.getBlock(xLeft, y);
				if(!Loader.isBlocked(block.getX()-App.TILE_SIZE, y)) {
					block.setX(xLeft-App.TILE_SIZE);
					isMovingLeft = true;
					super.moveToDest(DIR_LEFT);
				}else {
					isMovingLeft = false;
				}
			}
		}
		
		// Inherit Monster update method so rogue is able to kill player
		super.update(input, delta);
	}
	
	/**
	 * Checks if is moving left.
	 *
	 * @return true, if is moving left
	 */
	public boolean isMovingLeft() {
		return isMovingLeft;
	}
	
	/**
	 * Checks if is rogue near block.
	 *
	 * @param rogue the rogue
	 * @param x the x
	 * @return true, if is rogue near block
	 */
	public boolean isRogueNearBlock(Rogue rogue, float x) {
		float speed = App.TILE_SIZE;
		// Translate the direction to an x and y displacement
		float delta_x = 0;
		if(rogue.isMovingLeft()) {
			delta_x = -speed;
		}else {
			delta_x = speed;
		}
		return (rogue.getX() + delta_x == x);
	}
}
