				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

import org.newdawn.slick.Input;

/**
 * The Class Skeleton.
 */
public class Skeleton extends Monster {
	
	/** The update rate. */
	private static int UPDATE_RATE = 1000;
	
	/** The timer. */
	private static int timer = 0;
	
	/** The is moving up. */
	private boolean isMovingUp = true;
	
	/**
	 * Instantiates a new skeleton.
	 *
	 * @param x the x location
	 * @param y the y location
	 */
	Skeleton(float x, float y) {
		super(false, "res/skull.png", x, y);
	}
	
	
	@Override
	public void update(Input input, int delta) {
		
		timer+=delta;
		
		// to make skeleton move one tile per second
		if(timer>UPDATE_RATE) {
			
			if( isMovingUp && !Loader.isBlocked(super.getX(), super.getY() - App.TILE_SIZE)) {
				super.setY((super.getY() - App.TILE_SIZE));
				
			}
			else if(!Loader.isBlocked(super.getX(), super.getY() + App.TILE_SIZE)) {
				super.setY((super.getY() +App.TILE_SIZE));
				isMovingUp = false;
				
			}
			//change direction
			else {
				isMovingUp = true;
				return;
			}
			timer=0;
		}
		
		// Inherit Monster update method so skeleton is able to kill player
		super.update(input, delta);
		
	}
}
