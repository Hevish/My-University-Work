				/* Name: Hevish Cowlessur 
				 * 771425 
				 * (SPRITE CLASS) */


import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;

/**
 * The Class Sprite.
 * This class represents each sprite on the screen, including their graphics and behavior.
 */
public class Sprite {
	/*Direction constants */
	/** The Constant DIR_NONE. */
	public static final int DIR_NONE = 0;
	
	/** The Constant DIR_LEFT. */
	public static final int DIR_LEFT = 1;
	
	/** The Constant DIR_RIGHT. */
	public static final int DIR_RIGHT = 2;
	
	/** The Constant DIR_UP. */
	public static final int DIR_UP = 3;
	
	/** The Constant DIR_DOWN. */
	public static final int DIR_DOWN = 4;
	
	/* Define variables as private helps to separate the interface from the implementation */
	
	/** The y location */
	private float y;
	
	/** The x location */
	private float x;
	
	/** The image. */
	private Image image;
	
	/** The is blocked. */
	private boolean isBlocked;
	
	/** The image source code. */
	private String image_src;
	
	/**
	 * Instantiates a new sprite.
	 *
	 * @param isBlocked the is blocked
	 * @param image_src the image source code
	 * @param x the x location
	 * @param y the y location
	 */
	/* Construct each sprite with a blocked argument, tileType, x position and y position*/
	Sprite(boolean isBlocked, String image_src, float x, float y){
		
		try {
			image = new Image(image_src);
		} catch (SlickException e) {
			e.printStackTrace();
		}
		this.image_src = image_src;
		this.x = x;
		this.y = y;
		this.isBlocked = isBlocked;
	}
	
	/**
	 * Update.
	 * 
	 * Update sprite location 
	 * 
	 * @param input the input
	 * @param delta the delta
	 */
	
	public void update(Input input, int delta) {
		
	}
	
	/**
	 * Render.
	 * Draw the sprite 
	 * @param g the g
	 */
	public void render(Graphics g) {
		image.drawCentered(x, y);
	}
	
	/*@@@@ GETTERS and SETTERS @@@@*/
	
	/**
	 * Get the blocked status from each sprite
	 *
	 * @param x the x
	 * @param y the y
	 * @return the checks if is blocked
	 */
	public boolean getIsBlocked(float x, float y) {
		return isBlocked;
	}
	
	/**
	 * Sets the blocked status from each sprite
	 *
	 * @param blockedState the new blocked
	 */
	public void setBlocked(boolean blockedState) {
		this.isBlocked = blockedState;
	}
	
	/**
	 * Gets the x position of each sprite
	 *
	 * @return the x
	 */
	public float getX() {
		return this.x;
	}
	
	/**
	 * Gets the y position of each sprite
	 *
	 * @return the y
	 */
	public float getY() {
		return this.y;
	}
	
	/**
	 * Gets Image type from image_src
	 *
	 * @return the image
	 */
	public Image getImage() { 
		return this.image;
	}
	
	/**
	 * Gets the image.
	 *
	 * @param image the new image
	 */
	public void setImage(Image image) {
		this.image = image;
	}
	
	/**
	 * Gets the image source code.
	 *
	 * @return the image source code
	 */
	public String getImage_src() { 
		return this.image_src;
	}
	
	/**
	 * Sets the image source code.
	 *
	 * @param image_src the new image source code
	 */
	public void setImage_src(String image_src) {
	}
	
	/**
	 * Sets the y position
	 *
	 * @param y the new y
	 */

	public void setY(float y) {
		this.y = y;
	}
	
	/**
	 * Sets the x position
	 *
	 * @param x the new x
	 */
	public void setX(float x) {
		this.x = x;
	}		
}