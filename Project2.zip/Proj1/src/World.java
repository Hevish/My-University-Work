				/* Name: Hevish Cowlessur 
				 * 771425
				 * (WORLD CLASS) */

import java.util.ArrayList;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

/**
 * The Class World.
 * 
 * This class represents the entire game world
 */
public class World {
	
	/** The sprites. */
	private static ArrayList<Sprite> sprites;
	
	/** The level. */
	private static int lvl = 0;
	
	/**
	 * Instantiates a new world.
	 *
	 * @param lvl the level
	 * @throws SlickException the slick exception
	 */
	/* Load game world */
	public World(int lvl) throws SlickException {
		sprites = Loader.loadSprites("res/levels/"+lvl+".lvl");
	}
	
	/**
	 * Update.
	 *
	 *Update sprites which the game contains
	 * @param input the input
	 * @param delta the delta
	 * @throws SlickException the slick exception
	 */
	public void update(Input input, int delta) throws SlickException {	
		for(Sprite sprite : sprites) {
			if(sprite != null) {
				sprite.update(input, delta);
			}
		}
		
		// Load next level, clearing every previous info
		if(isLevelComplete()) {
			sprites.clear();
			lvl++;
			Player.setMoveCount(0);
			sprites = Loader.loadSprites("res/levels/"+lvl+".lvl");
		}
		
		//Restart Level, clearing every previous info
		if(input.isKeyPressed(Input.KEY_R) ||  Monster.restartLevel()) {
    		try {
    			sprites.clear();
    			Player.setMoveCount(0);
				sprites = Loader.loadSprites("res/levels/"+lvl+".lvl");
			} catch (SlickException e) {
				e.printStackTrace();
			}
    	}
	}
	
	
	/**
	 * Render.
	 *
	 * Draw the sprites and print move count
	 * @param g the g
	 * @throws SlickException the slick exception
	 */
	public void render(Graphics g) throws SlickException {
		for(Sprite sprite : sprites) {
			if(sprite != null) {
				
				sprite.render(g);
			}
		}
		
		// Prints the moves on the screen
		String s = String.format("Moves: %d", Player.getMoveCount());
		g.drawString(s, 0,0);
	}
	
	/**
	 * Extracts all sprites of a certain type
	 *
	 * @param type the type
	 * @return the sprites of type
	 */
	public static ArrayList<Sprite> getSpritesOfType(String type){
		
		type = "res/"+type+".png";
		ArrayList<Sprite> typeOfSprite = new ArrayList<Sprite>();
		
		for(Sprite s : sprites) {
			if(s.getImage_src().equals(type)) {
				typeOfSprite.add(s);
			}			
		}
		return typeOfSprite;
	}
	
	/**
	 * Extracts the sprite at a specific location
	 *
	 * @param image_src the image source code
	 * @param x the x location
	 * @param y the y location
	 * @return the sprite of type
	 */
	public static Sprite getSpriteOfType(String image_src, float x, float y) {
		ArrayList<Sprite> sprites = Loader.getSprite();
		
		for(Sprite s: sprites) {
			if(s.getX()==x && s.getY()==y && s.getImage_src().equals(image_src)) {
			 return s;	
			}			
		}
		return null;

	}
	
	/**
	 * Gets the player.
	 *
	 * @return the player
	 */ 
	public static Player getPlayer() {
		ArrayList<Sprite> sprites = Loader.getSprite();
		for(Sprite s : sprites) {
			if(s.getImage_src().equals(Player.PLAYER_SRC)) {			
				return (Player)s;
			}
		
		}
		return null;
	}
	
	/**
	 * Checks if there is a block at a particular location
	 *
	 * @param x the x coordinate
	 * @param y the y coordinate
	 * @return true, if is a block
	 */
	public static boolean isABlock(float x, float y) {
		ArrayList<Sprite> sprites = Loader.getSprite();
		for(Sprite s : sprites) {
			if(s.getImage_src().equals("res/stone.png") && s.getX()==x && s.getY()==y) {			
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Extracts the block at a particular location
	 *
	 * @param x the x
	 * @param y the y
	 * @return the block
	 */ 
	public static Block getBlock(float x, float y) {
		ArrayList<Sprite> sprites = Loader.getSprite();
		for(Sprite s : sprites) {
			if(s.getImage_src().equals("res/stone.png") && s.getX()==x && s.getY()==y) {			
				return (Block) s;
			}
		}
		return null;
	}
	
	/**
	 * Checks if is level complete.
	 *
	 * @return true, if is level complete
	 */
	public static boolean isLevelComplete() {
		return Block.areTargetsActivated();
	}
	
	
	/*@@@@ GETTERS AND SETTERS @@@*/
	
	/**
	 * Gets the lvl.
	 *
	 * @return the lvl
	 */
	public static int getLvl() {
		return lvl;
	}
	
	/**
	 * Sets the lvl.
	 *
	 * @param lvl the new lvl
	 */
	public static void setLvl(int lvl) {
		World.lvl = lvl;
	}
	
	/**
	 * Gets the sprites.
	 *
	 * @return the sprites
	 */
	public static ArrayList<Sprite> getSprites() {
		return sprites;
	}

	/**
	 * Sets the sprites.
	 *
	 * @param sprites the new sprites
	 */
	public static void setSprites(ArrayList<Sprite> sprites) {
		World.sprites = sprites;
	}
}