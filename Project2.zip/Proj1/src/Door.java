				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

/**
 * The Class Door.
 */
public class Door extends Tile {
	
	/**
	 * Instantiates a new door.
	 *
	 * @param x the x location
	 * @param y the y location
	 */
	Door(float x, float y) {
		super(true, "res/door.png", x, y);
	}
}
