				/* Name: Hevish Cowlessur 
				 * 771425 
				 */

import org.newdawn.slick.Input;

/**
 * The Class Ice.
 */
public class Ice extends Block {
	
	/** The ice moves. */
	private final int NUMOFICEMOVES=2;
	private Move[] iceMoves = new Move[NUMOFICEMOVES];
	
	/**
	 * Instantiates a new ice.
	 *
	 * @param x the x
	 * @param y the y
	 */
	Ice(float x, float y) {
		super(true, "res/ice.png", x, y);
		// store current location of ice as first element
		iceMoves[0]=new Move( Player.getMoveCount(), x, y);
	}
	
	@Override
	public void update(Input input, int delta) {
		Player player = World.getPlayer();
		
		//Update only if player is near block and player is about to move 
		if(isPlayerNearBlock(player, super.getX(), super.getY()) && !Player.onMove()) {
			
			int dir = Player.getDir(); // gets direction of player at every update
				if(dir == Player.DIR_LEFT) {
					
					// store current player location as first entry
					if(moveToDest(dir)) { 
						iceMoves[0] = new Move(Player.getMoveCount(), super.getX()+App.TILE_SIZE, super.getY());
					}
					player.moveToDest(dir);
					
					// keep moving until a blocked tile is reached
					while(!Loader.isBlocked(super.getX()-App.TILE_SIZE, super.getY())) {
							super.setX(super.getX()-App.TILE_SIZE);							
					}
					
					//store last ice location at second entry
					iceMoves[1]= new Move(Player.getMoveCount(), super.getX(), super.getY());
				}
				else if(dir == Player.DIR_UP) {
					
					if(moveToDest(dir)) {
						iceMoves[0]= new Move(Player.getMoveCount(), super.getX(), super.getY()+App.TILE_SIZE);
					}
					player.moveToDest(dir);
					
					while(!Loader.isBlocked(super.getX(), super.getY()-App.TILE_SIZE)) {
							super.setY(super.getY()-App.TILE_SIZE);
					}
					
					iceMoves[1]= new Move(Player.getMoveCount(), super.getX(), super.getY());
				}
				else if(dir == Player.DIR_DOWN) {
					
					if(moveToDest(dir)) {
						iceMoves[0]=new Move(Player.getMoveCount(), super.getX(), super.getY()-App.TILE_SIZE);
					}
					player.moveToDest(dir);
					
					while(!Loader.isBlocked(super.getX(), super.getY()+App.TILE_SIZE)) {

							super.setY(super.getY()+App.TILE_SIZE);
							
					}
					iceMoves[1]= new Move(Player.getMoveCount(), super.getX(), super.getY());
					
				}
				else if(dir == Player.DIR_RIGHT) {
					
					if(moveToDest(dir)) {
						iceMoves[0]= new Move(Player.getMoveCount(), super.getX()-App.TILE_SIZE, super.getY());
					}
					player.moveToDest(dir);
					
					while(!Loader.isBlocked(super.getX()+App.TILE_SIZE, super.getY())) {
							super.setX(super.getX()+App.TILE_SIZE);	
					}
					iceMoves[1] = new Move(Player.getMoveCount(), super.getX(), super.getY());
					
				}
			}
			// undo move of ice if possible
			if(Player.undo()) {
				undo(iceMoves);
			}
		}
	
	/**
	 * Undo.
	 *
	 * @param iceMoves stores the ice moves
	 * @return an arbitrary number because of overriding
	 */
	// Undo IceMoves
	public int undo(Move[] iceMoves) {
		if(iceMoves[0].getMoveCount()==Player.getMoveCount()) {
			super.setX(iceMoves[0].getX());
			super.setY(iceMoves[0].getY());
		}		
		return 0;
	}
		
}
