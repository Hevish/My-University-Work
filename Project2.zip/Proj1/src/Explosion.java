				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

/**
 * The Class Explosion.
 */
public class Explosion extends Effect{	
	
	/**
	 * Instantiates a new explosion.
	 *
	 * @param x the x location
	 * @param y the y location
	 */
	Explosion(float x, float y) {
		super(false, "res/explosion.png", x, y);
	}
}
