				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */ 

/**
 * The Class Wall.
 */
public class Wall extends Sprite {
	
	/**
	 * Instantiates a new wall.
	 *
	 * @param x the x location
	 * @param y the y location
	 * @param blocked is labeled as blocked
	 */
	public Wall(float x, float y){
		super(true, "res/wall.png", x, y);

	}

}
