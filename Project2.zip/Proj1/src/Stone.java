				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

/**
 * The Class Stone.
 */
public class Stone extends Block {
		
	/**
	 * Instantiates a new stone.
	 *
	 * @param x the x location
	 * @param y the y location
	 */
	public Stone(float x, float y){
		super(true, "res/stone.png", x, y);
	}
}
