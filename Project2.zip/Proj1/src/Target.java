				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

/**
 * The Class Target.
 */
public class Target extends Tile {
	
	/**
	 * Instantiates a new target.
	 *
	 * @param x the x location
	 * @param y the y location
	 */
	public Target(float x, float y){
		super(false, "res/target.png", x, y);
	}
}
