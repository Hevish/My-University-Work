				/* Name: Hevish Cowlessur 
				 * 771425
				 * 
				 */

/**
 * The Class Move.
 */
public class Move {
	
	/** The x and y coordinates */
	private float x, y;
	
	/** The move count. */
	private int moveCount;
	
	/** The sprite. */
	private Sprite sprite;
	
	/**
	 * Instantiates a new move.
	 *
	 * This second constructor is pretty handy
	 * @param moveCount the move count
	 * @param x the x
	 * @param y the y
	 */ 
	public Move(int moveCount,float x, float y) {
		this.setMoveCount(moveCount);
		this.x = x ;
		this.y = y;
	}
	
	
	/*@@@ GETTERS AND SETTERS @@@*/
	/**
	 * Gets the y.
	 *
	 * @return the y
	 */
	public float getY() {
		return y;
	}
	
	/**
	 * Sets the y.
	 *
	 * @param y the new y
	 */
	public void setY(float y) {
		this.y = y;
	}
	
	/**
	 * Gets the x.
	 *
	 * @return the x
	 */
	public float getX() {
		return x;
	}
	
	/**
	 * Sets the x.
	 *
	 * @param x the new x
	 */
	public void setX(float x) {
		this.x = x;
	}
	
	/**
	 * Gets the move count.
	 *
	 * @return the move count
	 */
	public int getMoveCount() {
		return moveCount;
	}
	
	/**
	 * Sets the move count.
	 *
	 * @param moveCount the new move count
	 */
	public void setMoveCount(int moveCount) {
		this.moveCount = moveCount;
	}
	
	/**
	 * Gets the sprite.
	 *
	 * @return the sprite
	 */
	public Sprite getSprite() {
		return sprite;
	}
	
	/**
	 * Sets the sprite.
	 *
	 * @param sprite the new sprite
	 */
	public void setSprite(Sprite sprite) {
		this.sprite = sprite;
	}

}
