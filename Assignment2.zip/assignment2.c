/*============================================================================*/
/*	COMP20005 ASSIGNMENT 2
	AUTHOR: HEVISH COWLESSUR
	STUDENT ID: 771425
	EMAIL ID: hcowlessur@student.unimelb.edu.au
	UNIVERSITY OF MELBOURNE 
	SPECIFICATION: This program solves a maze of maximum size 100x100. */
/*	OUR MOTTO: "Programming Is Fun!" */
/*============================================================================*/
#include <stdio.h>

/* Types */
#define WALL '#' 		 // no-go cells
#define GAP '.'  	 	 // passable cells
#define NEWLINE '\n'
#define REACH '+' 		 // reachable cells
#define NREACH '-'	 	 // non-reachable cells
#define NOTPATH ' '		 // not part of final path 
#define ODDCOSTPATH '.'

/* Sizes */
#define MAXROWS 100
#define MAXCOLS 100
#define MAXREPLACE MAXROWS*MAXCOLS /* Maximum number of reachable cells 
									and maximum cost as well*/

/* Flags */
#define END_OF_FILE -1
#define SOLVED 1      
#define UNSOLVED 0
#define LABELLED 1 
#define UNLABELLED 0
#define INCORRECT -1

#define ROW1 0
#define COL1 0

/* Structures declaration */
typedef struct{
	char type;
	int cost;
	int pathlabel;
}cell_t;

typedef struct {
	cell_t C[MAXROWS][MAXCOLS];
	int hassoln;
	int mincost;
}maze_t;

/* Function Prototypes */
void read_maze(maze_t *);
int getNumOfRows(maze_t *);
int getNumOfCols(maze_t *);
void print_maze(maze_t *);
void print_stage_1(maze_t *);
void assign_reachability(maze_t *);
void assign_Unreachables(maze_t *);
void print_stage_2(maze_t *);
void assign_initial_cost(maze_t *);
void assign_cost(maze_t *);
void print_stage_3(maze_t *);
void getmincost( maze_t *);
void label_final_path(maze_t *);
void print_stage_four(maze_t *);

/* the main program that holds it all together*/
int 
main(int argc, char *argv[]){
	maze_t M; /* The maze */
	read_maze(&M);
	print_stage_1(&M);
	assign_reachability(&M);
	print_stage_2(&M);
	print_stage_3(&M);
	if (M.hassoln) {
		label_final_path(&M);
	    print_stage_four(&M);
	} /* If M has no solution, do nothing more and end program! */
	
	return 0;
}		/* END OF MAIN FUNCTION */


/*Stage1: This function reads the maze. */
void read_maze(maze_t *M){
	int i, j;
	int flag;
	for(i=0; i<MAXROWS;i++){
		for(j=0; j<MAXCOLS; j++){
			if(scanf("%c", &M->C[i][j].type)!= 1){
				flag = END_OF_FILE;
				break;
			}
			if(M->C[i][j].type == NEWLINE){
				break;
			}
		}
		if(flag == END_OF_FILE){
			break;
		}
	}
}
/* Stage1: This function finds the number of rows in the maze. */
int getNumOfRows(maze_t *M){
	int i, j, flag;
	while(i<MAXROWS){
		for(j=0; j<MAXCOLS; j++){
			if((M->C[i][j+1].type == NEWLINE) &&
				(M->C[i+1][COL1].type != GAP && M->C[i+1][COL1].type !=WALL &&
				M->C[i+1][COL1].type != REACH && 
				M->C[i+1][COL1].type != NREACH)){ 
				flag = END_OF_FILE;		/* Thers's nothing in the line 
										after the last one */
				break;
			}
			if(M->C[i][j+1].type == NEWLINE){
				break;
			}
		}
		if(flag == END_OF_FILE){
			break;
		}
		i++;
	}
	int numOfRow = i + 1;
	return numOfRow;
}
/* Stage1: This function finds the number of columns in the maze. */
int getNumOfCols(maze_t *M){
	int i, j, flag;
	for(i=0; i<MAXROWS;i++){
		for(j=0; j<MAXCOLS; j++){
			if((M->C[i][j+1].type == NEWLINE) &&
				(M->C[i+1][COL1].type != GAP && M->C[i+1][COL1].type !=WALL &&
				M->C[i+1][COL1].type != REACH && 
				M->C[i+1][COL1].type != NREACH)){ 
				flag = END_OF_FILE; 
				break;
			}
			if(M->C[i][j+1].type == NEWLINE){
				break;
			}
		}
		if(flag == END_OF_FILE){
			break;
		}
	}
	int numOfCol = j + 1;
	return numOfCol;
}
/* Stage1: This function prints stage 1	after reading maze. */
void print_stage_1(maze_t *M){
	printf("\nStage 1\n=======\n");
	printf("maze has %d rows and %d columns\n",
			getNumOfRows(M), getNumOfCols(M));
	print_maze(M);
}
/* Stage2: This function checks for reachability of cells. */
void assign_reachability(maze_t *M){
	int numOfCols, numOfRows;
	numOfCols = getNumOfCols(M);
	numOfRows = getNumOfRows(M);
	int i, j, flag=LABELLED ;
	while(flag){
		flag = UNLABELLED;
		for(i=0; i<numOfRows;i++){
			for(j=0; j<numOfCols; j++){
				if(i==ROW1){	// Initialise start of row
					if(M->C[i][j].type == GAP){
						M->C[i][j].type = REACH;
					}
				}else {
					if(j==COL1 &&  M->C[i][j].type == GAP &&
						(M->C[i-1][j].type == REACH ||
						M->C[i][j+1].type == REACH ||
						M->C[i+1][j].type == REACH)){
					
						M->C[i][j].type = REACH;	
						flag = LABELLED;
					}if((j>COL1 && j<numOfCols-1) && M->C[i][j].type == GAP	&&
						(M->C[i+1][j].type == REACH ||
						M->C[i][j+1].type == REACH ||
						M->C[i-1][j].type == REACH ||
						M->C[i][j-1].type == REACH)){
					
						M->C[i][j].type = REACH;
						flag = LABELLED;
					}if(j==numOfCols-1 && M->C[i][j].type == GAP &&
						(M->C[i-1][j].type == REACH ||
						M->C[i][j-1].type == REACH ||
						M->C[i+1][j].type == REACH)){
					
						M->C[i][j].type = REACH;	
						flag = LABELLED;
					} 
				}
			}
			if(M->C[i+1][COL1].type != WALL &&
				M->C[i+1][COL1].type != GAP && M->C[i+1][COL1].type != REACH){
				break;	// End of maze is reached
			}
		}
	}
	assign_Unreachables(M);
}
/* Stage2: This function assigns '-' to all unreachable cells. */
void assign_Unreachables(maze_t *M){
	int i, j;
	for(i=0; i<MAXROWS;i++){
		for(j=0; j<MAXCOLS; j++){
			// Replace remaining GAP by NREACH
			if(M->C[i][j].type == GAP){
				M->C[i][j].type = NREACH;
			}
		}
		if(M->C[i+1][COL1].type != WALL && M->C[i+1][COL1].type != GAP &&
		M->C[i+1][COL1].type != REACH && M->C[i+1][COL1].type != NREACH){
			break; // End of maze is reached
		}
	}
}
/* Stage2: This function prints stage 2 after checking for reachability. */
void print_stage_2(maze_t *M){
	int  j, flag;
	int numOfCols, numOfRows;
	numOfCols = getNumOfCols(M);
	numOfRows = getNumOfRows(M);
	printf("\nStage 2\n=======\n");
	for(j=0; j< numOfCols; j++){
		if(M->C[numOfRows-1][j].type == REACH){
			flag = SOLVED;
			break;
		}
	}
	if(flag == SOLVED){
		printf("maze has a solution\n");
		M->hassoln = SOLVED;
	}else{
		printf("maze does not have a solution\n");
		M->hassoln = UNSOLVED;
	}
	print_maze(M);
}
/* Stage1,2: This function prints the modified maze. */
void print_maze(maze_t *M){
	int i,j;
	int numOfCols, numOfRows;
	numOfCols = getNumOfCols(M);
	numOfRows = getNumOfRows(M);
	for(i=0; i<numOfRows;i++){
		for(j=0; j<numOfCols; j++){
			printf("%c", M->C[i][j].type);
			printf("%c", M->C[i][j].type);
		}
		printf("\n");
	}
}
/*Stage3: This function initialises cost -1 in every cell and 0 to entry cell.*/
void assign_initial_cost(maze_t *M){
	int numOfCols, numOfRows;
	numOfCols = getNumOfCols(M);
	numOfRows = getNumOfRows(M);	
	int cost=INCORRECT;
	int i, j;
	/*Make cost of all cells INCORRECT initially  */
	/* INCORRECT == -1 means invalid cost!! */
	for(i=0; i < numOfRows; i++){
		for(j=0; j<numOfCols; j++){
				printf(" "); /* had to that because it was not assigning 
								the correct cost to each reachable cell on
								dimefox, don't know why!!!*/
				M->C[i][j].cost = INCORRECT;
		}
	}
	/* Initialise cost of entry cell to 0 */
	for(j=0; j<numOfCols; j++){
		if(M->C[ROW1][j].type == REACH){
			M->C[ROW1][j].cost = cost + 1 ;
		}
	}
}
/* Stage3 : This function assigns costs to reachable cells. */
void assign_cost(maze_t *M){
	assign_initial_cost(M);
	int numOfCols, numOfRows;
	numOfCols = getNumOfCols(M);
	numOfRows = getNumOfRows(M);	
	int i, j;
	int flag = LABELLED;
	while(flag){
		flag = UNLABELLED;
		for(i=0; i < numOfRows; i++){
			for(j=0; j<numOfCols; j++){
				if(M->C[i][j].cost != INCORRECT){ /* Valid Cost! This is needed.
					Compare with neighbour and make neighbour's cost
					1 more than current cell's cost*/
					if((i < numOfRows-1) && M->C[i+1][j].cost == INCORRECT && 
						M->C[i+1][j].type == REACH ){
						M->C[i+1][j].cost = M->C[i][j].cost + 1;
						flag = LABELLED;
					}			
					if((i > ROW1) &&  M->C[i-1][j].cost == INCORRECT && 
						M->C[i-1][j].type == REACH){
						M->C[i-1][j].cost = M->C[i][j].cost + 1;
						flag = LABELLED;
					}
					if((j< numOfCols-1) && M->C[i][j+1].cost == INCORRECT && 
						M->C[i][j+1].type == REACH){
						M->C[i][j+1].cost = M->C[i][j].cost + 1;
						flag = LABELLED;
					}
					if((j > COL1) && M->C[i][j-1].cost == INCORRECT && 
						M->C[i][j-1].type == REACH){
						M->C[i][j-1].cost = M->C[i][j].cost + 1;
						flag = LABELLED;
					}
					/* if difference between neighbour and current cell's cost
					is more than 1, fix it by making 
					neighbour's cost 1 more than current cell's cost*/
					if((i < numOfRows-1) && 
						(M->C[i+1][j].cost - M->C[i][j].cost > 1)){
						M->C[i+1][j].cost = M->C[i][j].cost + 1;
						flag = LABELLED;
					}
					if((i > ROW1) && 
						(M->C[i-1][j].cost - M->C[i][j].cost > 1)){
						M->C[i-1][j].cost = M->C[i][j].cost + 1;
						flag = LABELLED;
					}
					if((j< numOfCols-1) && 
						(M->C[i][j+1].cost - M->C[i][j].cost > 1)){
						M->C[i][j+1].cost = M->C[i][j].cost + 1;
						flag = LABELLED;
					}
					if((j > COL1) && (M->C[i][j-1].cost - M->C[i][j].cost > 1)){
						M->C[i][j-1].cost = M->C[i][j].cost + 1;
						flag = LABELLED;
					}
				}
			}
		}
	}	
	return;
}
/* Stage3: This function finds the minimum cost required to solve the maze. */
void getmincost(maze_t *M){
	int maxColnum, maxRownum;
	maxColnum = getNumOfCols(M) - 1;
	maxRownum = getNumOfRows(M) - 1;
	int costarray[maxRownum];  // maximum number of exits == maxRownum
	int h=0;
	int j;
	/* Store all final costs in costarray[] and find the minimum cost */
	for(j=0; j <= maxColnum; j++){
		if(M->C[maxRownum][j].type == REACH){
			costarray[h] = M->C[maxRownum][j].cost; 
			h++; // buddy  variable
		}
	}
	int mincost = MAXREPLACE; //maximise mincost intially
	int i;
	for(i=0; i < h; i++){
		if(costarray[i] < mincost){
			mincost = costarray[i];
		}
	}	
	if(h > 0){ // => at least 1 exit 
		M->mincost = mincost;
		printf("maze has a solution with cost %d\n", M->mincost);	
	}else{
		printf("maze does not have a solution\n");
	}
	return;
}
/* Stage3: This function prints stage 3. */
void print_stage_3(maze_t *M){
	assign_cost(M);
	printf("\nStage 3\n=======\n");
	getmincost(M);
	int i,j;
	int numOfCols, numOfRows;
	numOfCols = getNumOfCols(M);
	numOfRows = getNumOfRows(M);
	
	for(i=0; i<numOfRows;i++){
		for(j=0; j<numOfCols; j++){
			if(M->C[i][j].type != REACH){ // WALL or NREACH printed
				printf("%c", M->C[i][j].type);
				printf("%c", M->C[i][j].type);
			}else{ // EVEN cost printed and REACH printed for ODD ones 
				if(M->C[i][j].cost % 2 == 0){
					printf("%02d", M->C[i][j].cost%100);
							/* %100 operator prints only last 2 digits
								if cost > 100*/
				}else{ 						  
					printf("%c", M->C[i][j].type);
					printf("%c", M->C[i][j].type);
				}
			}
		}
		printf("\n");
	}
	return;
}
/*Stage4: This function labels the final path. */
void label_final_path(maze_t *M){
	int numOfCols, numOfRows;
	numOfCols = getNumOfCols(M);
	numOfRows = getNumOfRows(M);
	int j,lastrow;
	lastrow = numOfRows -1;
	/* Use mincost from stage 3 to find leftmost exit */
	for(j=0; j < numOfCols; j++){
		printf(" "); // same reason as before
		if(M->C[lastrow][j].cost == M->mincost){
			M->C[lastrow][j].pathlabel = LABELLED;
			break;
		}
	}
	int i; 
	int cost=M->mincost;
	M->C[lastrow][j].cost = cost;
	
	while(cost > 0){ /*The guard. As soon as cost== 0 => reached the entry! */
		for(i=lastrow; i >= 0; i--){
			for(j= 0; j < numOfCols; j++){
				/*Stategy is to label path, assign cost only once and move on*/
				if(M->C[i][j].pathlabel==LABELLED && (M->C[i][j].cost==cost)){
					if(M->C[i][j+1].pathlabel != LABELLED && 
						M->C[i][j+1].type == REACH && 
						(M->C[i][j].cost - M->C[i][j+1].cost == 1)){
					
						M->C[i][j+1].pathlabel = LABELLED;
						cost--;
					}else if(M->C[i-1][j].pathlabel != LABELLED && 
						M->C[i-1][j].type == REACH && 
						(M->C[i][j].cost - M->C[i-1][j].cost == 1)){
					
						M->C[i-1][j].pathlabel = LABELLED;
						cost--;
					}else if(M->C[i+1][j].pathlabel != LABELLED && 
						M->C[i+1][j].type == REACH && 
						(M->C[i][j].cost - M->C[i+1][j].cost == 1)){
					
						M->C[i+1][j].pathlabel = LABELLED;						
						cost--;
					}else if(M->C[i][j-1].pathlabel != LABELLED && 
						M->C[i][j-1].type == REACH && 
						(M->C[i][j].cost - M->C[i][j-1].cost == 1)){
					
						M->C[i][j-1].pathlabel = LABELLED;					
						cost--;	
					}
				}
			}
		}
	}
	return;
}
/*Stage4: This function prints stage 4. */
void print_stage_four(maze_t *M){
	printf("\nStage 4\n=======\n");
	printf("maze solution\n");
	int numOfCols, numOfRows;
	numOfCols = getNumOfCols(M);
	numOfRows = getNumOfRows(M);
	int i, j;
	for(i=0; i < numOfRows; i++){
		for(j=0; j < numOfCols; j++){
			if(M->C[i][j].type != REACH){
				printf("%c", M->C[i][j].type);
				printf("%c", M->C[i][j].type);				
			}else{
				if(M->C[i][j].pathlabel == LABELLED){
					if(M->C[i][j].cost % 2 == 0){ // even cost
						printf("%02d", M->C[i][j].cost % 100);
					}else{ // odd cost 
						printf("%c", ODDCOSTPATH);
						printf("%c", ODDCOSTPATH);
					}
				}else{ // not labelled
					printf("%c", NOTPATH);
					printf("%c", NOTPATH);
				}
			}
		}
		printf("\n");
	}
	return;
}
                     /* Programming is indeed fun :D ! */
/*=========================== END OF ASSIGNMENT 2 ============================*/