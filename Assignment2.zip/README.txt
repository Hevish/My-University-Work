This project consists of solving a maze in 4 stages. It solves the maze with the least cost to exit it. 
The c code should be run along with the test files. 